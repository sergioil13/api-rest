package com.openwebinars.todo.security;

import org.modelmapper.ModelMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;

import com.openwebinars.todo.error.CustomAccessDeniedHandler;
import com.openwebinars.todo.error.CustomAuthenticationEntryPoint;

import lombok.RequiredArgsConstructor;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
@RequiredArgsConstructor
public class SecurityConfig {

    private final CustomAccessDeniedHandler customAccessDeniedHandler;
    private final CustomAuthenticationEntryPoint customAuthenticationEntryPoint;


    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable()) // Deshabilitamos CSRF para APIs REST [cite: 114]
            .httpBasic(Customizer.withDefaults()) // Usamos Basic Auth como pide el PDF [cite: 100]
            .sessionManagement(session -> session
                .sessionCreationPolicy(SessionCreationPolicy.STATELESS)) // Comunicación Stateless [cite: 98]
            .authorizeHttpRequests(authz -> authz
                // 1. Endpoints públicos: Swagger y Registro [cite: 88, 112]
                .requestMatchers("/v3/api-docs/**", "/swagger-ui/**", "/auth/register").permitAll()
                
                // 2. Endpoints de ADMIN: Promocionar y degradar usuarios 
                .requestMatchers("/admin/**").hasRole("ADMIN")
                
                // 3. Endpoints de GESTOR/ADMIN: CRUD de categorías [cite: 70, 72]
                .requestMatchers("/category/**").hasAnyRole("ADMIN", "GESTOR")
                
                // 4. Endpoints de USUARIO: Gestión de sus propias tareas [cite: 74, 108]
                .requestMatchers("/tasks/**", "/tag/**").hasRole("USER")
                
                .anyRequest().authenticated()
            );
        
        // Para que los errores HTTP sean correctos (401, 403) [cite: 114]
        http.exceptionHandling(excep -> {
            excep.authenticationEntryPoint(customAuthenticationEntryPoint);
            excep.accessDeniedHandler(customAccessDeniedHandler);
        });

        return http.build();
    }
    
    @Bean
    public ModelMapper modelMapper() {
        return new ModelMapper();
    }

}
