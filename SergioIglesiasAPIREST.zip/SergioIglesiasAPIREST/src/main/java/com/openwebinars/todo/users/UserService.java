package com.openwebinars.todo.users;

import org.modelmapper.ModelMapper;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.openwebinars.todo.model.UserRole;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final ModelMapper modelMapper;
    public User save(NewUserRequestDto newUser) {
        User user = new User();
        user.setUsername(newUser.getUsername());
        user.setEmail(newUser.getEmail());
        user.setFullname(newUser.getFullname());
        
        // Encriptamos antes de guardar 
        user.setPassword(passwordEncoder.encode(newUser.getPassword()));
        
        // Asignamos el rol inicial 
        user.setRole(UserRole.USER);
        
        return userRepository.save(user);
    }
    
    
    public UserResponseDto register(NewUserRequestDto req) {
        User u = User.builder()
            .username(req.getUsername())
            .password(passwordEncoder.encode(req.getPassword()))
            .email(req.getEmail())       // No olvides el email
            .fullname(req.getFullname()) // No olvides el fullname
            .role(UserRole.USER)
            .build();
            
        User saved = userRepository.save(u);
        return modelMapper.map(saved, UserResponseDto.class);
    }
}
