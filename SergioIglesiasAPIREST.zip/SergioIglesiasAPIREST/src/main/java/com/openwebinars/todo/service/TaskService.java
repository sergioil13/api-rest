package com.openwebinars.todo.service;

import com.openwebinars.todo.dto.EditTaskCommand;
import com.openwebinars.todo.error.TaskNotFoundException;
import com.openwebinars.todo.model.Task;
import com.openwebinars.todo.repos.TaskRepository;
import com.openwebinars.todo.users.User;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class TaskService {

    private final TaskRepository taskRepository;

    // ... findAll, findByAuthor y findById se mantienen igual ...
    
    public Task findById(Long id) {
        return taskRepository.findById(id)
                .orElseThrow(() -> new TaskNotFoundException(id));
    }
    
    
    public List<Task> findByAuthor(User author) {
        List<Task> tasks = taskRepository.findByAuthor(author);
        
        // Si queremos ser estrictos y lanzar excepción si el usuario no tiene tareas:
        if (tasks.isEmpty()) {
            throw new TaskNotFoundException("Este usuario aún no tiene tareas creadas");
        }
        
        return tasks;
    }
    
    /**
     * Crea una nueva tarea asignando el autor logueado.
     */
    public Task save(EditTaskCommand cmd, User author) {
        return taskRepository.save(
                Task.builder()
                        .title(cmd.title())
                        .description(cmd.description())
                        .deadline(cmd.deadline())
                        .author(author)
                        .completed(false) // Por defecto al crear
                        .build()
        );
    }

    /**
     * Edita una tarea PERO comprueba que el autor sea el dueño.
     */
    public Task edit(EditTaskCommand cmd, Long id, User userLogueado) {
        return taskRepository.findById(id)
                .map(t -> {
                    // VERIFICACIÓN DE SEGURIDAD
                    if (!t.getAuthor().equals(userLogueado)) {
                        throw new RuntimeException("No tienes permiso para editar esta tarea");
                    }
                    
                    t.setTitle(cmd.title());
                    t.setDescription(cmd.description());
                    t.setDeadline(cmd.deadline());
                    return taskRepository.save(t);
                })
                .orElseThrow(() -> new TaskNotFoundException(id));
    }

    /**
     * Borra una tarea solo si el usuario es el dueño.
     */
    public void delete(Long id, User userLogueado) {
        Task task = findById(id);
        if (task.getAuthor().equals(userLogueado)) {
            taskRepository.delete(task);
        } else {
            throw new RuntimeException("No tienes permiso para borrar esta tarea");
        }
    }
}
