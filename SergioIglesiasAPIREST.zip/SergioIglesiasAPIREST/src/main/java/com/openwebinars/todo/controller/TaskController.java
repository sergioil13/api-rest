package com.openwebinars.todo.controller;



import java.util.List;



import com.openwebinars.todo.dto.EditTaskCommand;
import com.openwebinars.todo.dto.GetTaskDto;
import com.openwebinars.todo.service.TaskService;
import com.openwebinars.todo.users.User;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PostAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/task") // Quitamos la "/" del final para evitar problemas de rutas
@RequiredArgsConstructor
@SecurityRequirement(name = "basicAuth")
public class TaskController {

    private final TaskService taskService;

    @Operation(summary = "Obtener todas las tareas del usuario")
    @GetMapping
    public List<GetTaskDto> getAll(@AuthenticationPrincipal User author) {
        return taskService.findByAuthor(author)
                .stream()
                .map(GetTaskDto::of)
                .toList();
    }

    @Operation(summary = "Obtener una tarea por ID")
    @PostAuthorize("returnObject.author.username == authentication.principal.username")
    @GetMapping("/{id}")
    public GetTaskDto getById(@PathVariable Long id) {
        return GetTaskDto.of(taskService.findById(id));
    }

    @Operation(summary = "Crear una tarea")
    @PostMapping
    public ResponseEntity<GetTaskDto> create(
            @RequestBody EditTaskCommand cmd,
            @AuthenticationPrincipal User author
    ) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(GetTaskDto.of(taskService.save(cmd, author)));
    }

    @Operation(summary = "Editar una tarea")
    @PutMapping("/{id}")
    public GetTaskDto edit(
            @RequestBody EditTaskCommand cmd,
            @PathVariable Long id,
            @AuthenticationPrincipal User userLogueado
    ) {
        // Pasamos el usuario logueado en lugar de null
        return GetTaskDto.of(taskService.edit(cmd, id, userLogueado));
    }

    @Operation(summary = "Eliminar una tarea")
    @ApiResponse(responseCode = "204")
    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(
            @PathVariable Long id,
            @AuthenticationPrincipal User userLogueado
    ) {
        // Pasamos el usuario logueado en lugar de null
        taskService.delete(id, userLogueado);
        return ResponseEntity.noContent().build();
    }
}