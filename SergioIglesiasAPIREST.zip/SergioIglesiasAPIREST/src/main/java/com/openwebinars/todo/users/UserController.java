package com.openwebinars.todo.users;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController // IMPORTANTE: Indica que esto es una API REST
@RequiredArgsConstructor // Crea el constructor para inyectar UserService
public class UserController {

    private final UserService userService;

    // Esta ruta debe coincidir con la que pusiste en .permitAll() de SecurityConfig
    @PostMapping("/auth/register")
    public ResponseEntity<UserResponseDto> register(@RequestBody NewUserRequestDto newUser) {
        
        // Llamamos al servicio que creamos con ModelMapper y BCrypt
        UserResponseDto saved = userService.register(newUser);
        
        // Devolvemos un 201 Created con el usuario (sin password)
        return ResponseEntity.status(HttpStatus.CREATED).body(saved);
    }

}