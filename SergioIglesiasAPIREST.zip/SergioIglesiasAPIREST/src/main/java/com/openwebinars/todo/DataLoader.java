package com.openwebinars.todo;
import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.openwebinars.todo.model.Category;
import com.openwebinars.todo.model.Tag;
import com.openwebinars.todo.model.Task;
import com.openwebinars.todo.model.UserRole;
import com.openwebinars.todo.repos.CategoryRepository;
import com.openwebinars.todo.repos.TagRepository;
import com.openwebinars.todo.repos.TaskRepository;
import com.openwebinars.todo.users.User;
import com.openwebinars.todo.users.UserRepository;

@Component
public class DataLoader implements CommandLineRunner {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    private TaskRepository taskRepository;

    @Autowired
    private TagRepository tagRepository;

    @Override
    public void run(String... args) throws Exception {
        
        // 1. Crear Roles/Usuarios si no existen
        if (userRepository.count() == 0) {
            System.out.println("--- Cargando datos de prueba iniciales ---");

            User admin = User.builder()
                    .username("admin")
                    .password("1234") // En el futuro usaremos BCrypt
                    .email("admin@todo.com")
                    .fullname("Administrador del Sistema")
                    .role(UserRole.ADMIN)
                    
                    .build();

            User user = User.builder()
                    .username("sergio")
                    .password("1234")
                    .email("sergio@todo.com")
                    .fullname("Sergio Iglesias")
                    .role(UserRole.USER)
                    
                    .build();

            userRepository.save(admin);
            userRepository.save(user);

            // 2. Crear Categorías
            Category cat1 = new Category();
            cat1.setTitle("Trabajo");
            categoryRepository.save(cat1);

            Category cat2 = new Category();
            cat2.setTitle("Personal");
            categoryRepository.save(cat2);

            // 3. Crear Tags
            Tag tagUrgente = new Tag();
            tagUrgente.setName("Urgente");
            tagRepository.save(tagUrgente);

            Tag tagFacil = new Tag();
            tagFacil.setName("Fácil");
            tagRepository.save(tagFacil);

            // 4. Crear una Tarea de prueba para el usuario
            Task t1 = new Task();
            t1.setTitle("Terminar el Día 1 del proyecto");
            t1.setDescription("Configurar entidades, repositorios y MySQL");
            t1.setCompleted(true);
            t1.setCreatedAt(LocalDateTime.now());
            t1.setDeadline(LocalDateTime.now().plusDays(1));
            t1.setPriority("ALTA");
            t1.setAuthor(user);
            t1.setCategory(cat1);
            t1.getTags().add(tagUrgente);

            taskRepository.save(t1);

            System.out.println("--- ¡Datos de prueba cargados con éxito! ---");
        } else {
            System.out.println("--- La base de datos ya contiene datos, saltando DataLoader ---");
        }
    }
}