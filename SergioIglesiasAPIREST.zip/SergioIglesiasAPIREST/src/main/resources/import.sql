INSERT INTO task (created_at, deadline, id, title, description) VALUES (CURRENT_TIMESTAMP, '2025-12-31', 1, 'Comprar comida', 'Ir al supermercado');
INSERT INTO task (created_at, deadline, id, title, description) VALUES (CURRENT_TIMESTAMP, '2025-11-30', 2, 'Hacer ejercicio', 'Rutina de 45 minutos');
INSERT INTO task (created_at, deadline, id, title, description) VALUES (CURRENT_TIMESTAMP, '2025-10-15', 3, 'Estudiar inglés', 'Repasar vocabulario');
INSERT INTO task (created_at, deadline, id, title, description) VALUES (CURRENT_TIMESTAMP, '2025-09-01', 4, 'Limpiar el apartamento', 'Barrer y fregar el suelo');
INSERT INTO task (created_at, deadline, id, title, description) VALUES (CURRENT_TIMESTAMP, '2025-08-20', 5, 'Pagar facturas', 'Luz, agua e internet');
INSERT INTO task (created_at, deadline, id, title, description) VALUES (CURRENT_TIMESTAMP, '2025-07-10', 6, 'Llamar al médico', 'Pedir cita para revisión');
INSERT INTO task (created_at, deadline, id, title, description) VALUES (CURRENT_TIMESTAMP, '2025-06-05', 7, 'Revisar correos', 'Responder correos pendientes');
INSERT INTO task (created_at, deadline, id, title, description) VALUES (CURRENT_TIMESTAMP, '2025-05-01', 8, 'Preparar presentación', 'Diapositivas para el lunes');
INSERT INTO task (created_at, deadline, id, title, description) VALUES (CURRENT_TIMESTAMP, '2025-04-25', 9, 'Renovar el DNI', 'Pedir cita en comisaría');
INSERT INTO task (created_at, deadline, id, title, description) VALUES (CURRENT_TIMESTAMP, '2025-04-30', 10, 'Organizar escritorio', 'Ordenar archivos del ordenador');

INSERT INTO user_entity (id, email, username, password, is_admin) VALUES (NEXTVAL('user_entity_seq'), 'pepe@openwebinars.net', 'pepe', '{noop}12345', false);
UPDATE task SET author_id = CURRVAL('user_entity_seq');
ALTER SEQUENCE task_seq RESTART WITH 11;

